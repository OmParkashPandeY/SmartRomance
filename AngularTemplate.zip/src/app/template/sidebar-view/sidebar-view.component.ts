import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sidebar-view',
  templateUrl: './sidebar-view.component.html',
  styleUrls: ['./sidebar-view.component.scss']
})
export class SidebarViewComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
